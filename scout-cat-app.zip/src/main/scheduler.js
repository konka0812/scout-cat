import { getStore } from "./store.js";
import { runPipeline } from "../common/engines/pipeline.js";
import { powerMonitor } from "electron";
import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileP = promisify(execFile);

/** 额度/登录失效关键词（命中则暂停调度并提示） */
const QUOTA_ERRORS = ["401", "402", "429", "unauthorized", "insufficient", "balance", "余额", "登录", "quota", "rate limit"];

export class Scheduler {
  constructor({ petWindow } = {}) {
    this.petWindow = petWindow;
    this.timer = null;
    this.running = false;
    this.lastRun = null;
    this.lastStatus = "idle";
    this.lastError = "";
    this.bubblePending = [];
    this.lastSystemSleep = null;
    this.paused = false;
    this.rotation = 0;
    this.fullscreen = false;
    this.lastNotifyAttempt = null;
    this.setupPowerMonitor();
    this.setupFullscreenWatch();
  }

  /** 全屏/专注状态检测（文档第 3.1 节） */
  async checkFullscreen() {
    if (process.platform !== "win32") return false;
    try {
      const script = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32 {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
  [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);
  [DllImport("user32.dll")] public static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO info);
  public struct RECT { public int Left, Top, Right, Bottom; }
  public struct MONITORINFO { public uint cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags; }
}
"@
$hwnd = [Win32]::GetForegroundWindow()
if ($hwnd -eq [IntPtr]::Zero) { Write-Output "0"; exit }
if ([Win32]::IsZoomed($hwnd)) { Write-Output "1"; exit }
$rect = New-Object Win32+RECT
[Win32]::GetWindowRect($hwnd, [ref]$rect) | Out-Null
$mon = [Win32]::MonitorFromWindow($hwnd, 2)
$mi = New-Object Win32+MONITORINFO
$mi.cbSize = [System.Runtime.InteropServices.Marshal]::SizeOf($mi)
[Win32]::GetMonitorInfo($mon, [ref]$mi) | Out-Null
$w = $rect.Right - $rect.Left
$h = $rect.Bottom - $rect.Top
$mw = $mi.rcMonitor.Right - $mi.rcMonitor.Left
$mh = $mi.rcMonitor.Bottom - $mi.rcMonitor.Top
if ($w -ge $mw -and $h -ge $mh) { Write-Output "1" } else { Write-Output "0" }
`.trim();
      const { stdout } = await execFileP("powershell.exe", ["-NoProfile", "-Command", script], { timeout: 5000 });
      return stdout.trim() === "1";
    } catch {
      return false;
    }
  }

  /** 定期检查全屏状态（每 5 秒） */
  setupFullscreenWatch() {
    this._fsTimer = setInterval(async () => {
      const was = this.fullscreen;
      this.fullscreen = await this.checkFullscreen();
      // 从全屏恢复时，尝试弹出积压气泡
      if (was && !this.fullscreen) {
        this.lastSystemSleep = null;
        this.tryFlushPending();
      }
    }, 5000);
  }

  setupPowerMonitor() {
    powerMonitor.on("suspend", () => {
      this.lastSystemSleep = Date.now();
      this.stop();
    });
    powerMonitor.on("resume", () => {
      if (this.lastSystemSleep) {
        const elapsed = Date.now() - this.lastSystemSleep;
        this.lastSystemSleep = null;
        if (elapsed > 60_000) this.runPatrol();
      }
      const minutes = getStore().get("settings.searchIntervalMinutes", 60);
      this.reschedule(minutes);
      this.tryFlushPending();
    });
  }

  start() {
    const minutes = getStore().get("settings.searchIntervalMinutes", 60);
    this.reschedule(minutes);
    setTimeout(() => this.runPatrol(), 20000);
  }

  reschedule(minutes) {
    this.stop();
    const ms = Math.max(Number(minutes) || 60, 1) * 60 * 1000;
    this.timer = setInterval(() => this.runPatrol(), ms);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this._fsTimer) {
      clearInterval(this._fsTimer);
      this._fsTimer = null;
    }
  }

  isQuotaError(error) {
    if (!error) return false;
    const s = String(error).toLowerCase();
    return QUOTA_ERRORS.some((k) => s.includes(k.toLowerCase()));
  }

  async runPatrol() {
    if (this.running) return null;
    if (this.paused) return { ok: false, items: [], error: "已暂停：额度或登录失效，请在设置中检查" };
    this.running = true;
    this.lastStatus = "running";
    this.petWindow?.play("walk");   // 巡逻中
    try {
      const store = getStore();
      const settings = store.get("settings");
      // 展开 openai 配置（openai.js 从 cfg.baseURL/apiKey 等读取）
      const oc = settings.openai || {};
      const cfg = {
        baseURL: oc.baseURL || "",
        apiKey: oc.apiKey || "",
        model: oc.model || "deepseek-chat",
        searchKey: oc.searchKey || "",
        searchBase: oc.searchBase || "https://api.deepseek.com",
        interests: settings.interests || [],
        blockedTopics: settings.blockedTopics || [],
        watchTasks: store.get("watchTasks", []),
        lastCheck: store.get("lastCheck"),
        engine: settings.engine || "demo",
        openai: oc,
        feedback: settings.feedback || {},
        queryCount: settings.queryCount || 3,
        fetchLimit: settings.fetchLimit || 6,
        modelMaxTokens: settings.modelMaxTokens || 3000,
        eventRetentionDays: settings.eventRetentionDays || 30,
        useJsonMode: settings.useJsonMode !== false,
        rotation: this.rotation++,
      };
      const result = await runPipeline(cfg);
      this.lastStatus = result?.ok ? "success" : "error";
      this.lastError = result?.error || "";
      this.lastRun = Date.now();
      store.set("lastCheck", this.lastRun);

      if (!result?.ok && this.isQuotaError(result?.error)) {
        this.paused = true;
        this.stop();
        this.petWindow?.showBubble({
          title: "需要你处理",
          summary: "额度或登录已失效，巡逻已暂停。请在设置里检查后重新保存。",
          source: "系统",
          url: "",
        });
        return result;
      }

      if (result?.items?.length) {
        this.petWindow?.play("discover");
        this.notifyItems(result.items);
      } else {
        this.petWindow?.play("sleep");   // 没有新消息，睡觉
      }
      // 每次巡逻后尝试清空积压
      this.tryFlushPending();
      return result;
    } catch (e) {
      this.lastStatus = "error";
      this.lastError = e?.message || String(e);
      return null;
    } finally {
      this.running = false;
    }
  }

  /** 是否允许弹气泡（每日上限 + 免打扰 + 全屏 + 月度上限） */
  shouldBubble() {
    const store = getStore();
    const settings = store.get("settings");
    const today = new Date().toDateString();
    if (store.get("bubbleDate") !== today) {
      store.set("bubbleDate", today);
      store.set("bubbleCountToday", 0);
    }
    const count = store.get("bubbleCountToday", 0);
    const limit = settings.dailyBubbleLimit ?? 3;
    if (limit > 0 && count >= limit) return false;

    // 月度上限
    const month = new Date().toISOString().slice(0, 7);
    if (store.get("monthlyBubbleDate") !== month) {
      store.set("monthlyBubbleDate", month);
      store.set("monthlyBubbleCount", 0);
    }
    const monthlyLimit = settings.monthlyBubbleLimit || 0;
    if (monthlyLimit > 0 && store.get("monthlyBubbleCount", 0) >= monthlyLimit) return false;

    // 免打扰
    const quiet = settings.quietHours;
    if (quiet?.enabled) {
      const now = new Date();
      const mins = now.getHours() * 60 + now.getMinutes();
      const [sh, sm] = (quiet.start || "22:00").split(":").map(Number);
      const [eh, em] = (quiet.end || "08:00").split(":").map(Number);
      const start = sh * 60 + sm;
      const end = eh * 60 + em;
      if (start <= end) {
        if (mins >= start && mins < end) return false;
      } else {
        if (mins >= start || mins < end) return false;
      }
    }

    // 全屏/专注状态暂缓
    if (this.fullscreen) return false;

    return true;
  }

  /** 关注任务是否突破每日上限 */
  shouldBypassLimit(item) {
    const settings = getStore().get("settings");
    if (!settings.watchBypassLimit) return false;
    return Boolean(item?.watchTaskId);
  }

  /** 处理提醒候选：最新一条总是气泡提醒，其余按上限 */
  notifyItems(items) {
    const store = getStore();
    const merged = this.mergeDiscoveries(store.get("discoveries", []), items);
    store.set("discoveries", merged);
    if (!items.length) return;

    // 最新一条（items[0]）总是气泡提醒
    const first = items.find((i) => i.shouldNotify !== false) || items[0];
    if (!first) return;
    this.petWindow?.showBubble(first);
    store.set("bubbleCountToday", (store.get("bubbleCountToday", 0) + 1));
    store.set("monthlyBubbleCount", (store.get("monthlyBubbleCount", 0) + 1));
    this.markNotified(first);

    // 其余按每日上限
    const rest = items.filter((i) => i !== first);
    if (!rest.length) return;
    if (this.shouldBubble() || this.shouldBypassLimit(rest[0])) {
      const second = rest.find((i) => i.shouldNotify !== false) || rest[0];
      this.petWindow?.showBubble(second);
      store.set("bubbleCountToday", (store.get("bubbleCountToday", 0) + 1));
      store.set("monthlyBubbleCount", (store.get("monthlyBubbleCount", 0) + 1));
      this.markNotified(second);
      this.bubblePending.push(...rest.filter((i) => i !== second));
    } else {
      this.bubblePending.push(...rest);
    }
  }

  /** 标记通知已展示 */
  markNotified(item) {
    const store = getStore();
    const notifs = store.get("notifications", []);
    const n = notifs.find((x) => x.url === item.url || (item.eventId && x.eventId === item.eventId));
    if (n) {
      n.status = "shown";
      n.notifiedAt = new Date().toISOString();
      store.set("notifications", notifs);
    }
  }

  /** 尝试弹出积压气泡（恢复时合并展示，不集中轰炸） */
  tryFlushPending() {
    if (!this.bubblePending.length) return;
    if (!this.shouldBubble()) return;
    const store = getStore();
    // 恢复时只弹一条最旧的，其余留到下次
    const item = this.bubblePending.shift();
    if (item) {
      this.petWindow?.showBubble(item);
      store.set("bubbleCountToday", (store.get("bubbleCountToday", 0) + 1));
      store.set("monthlyBubbleCount", (store.get("monthlyBubbleCount", 0) + 1));
      this.markNotified(item);
    }
  }

  mergeDiscoveries(existing, incoming) {
    const seen = new Set(existing.map((d) => d.url));
    const out = [...existing];
    for (const item of incoming || []) {
      if (!item?.url || seen.has(item.url)) continue;
      seen.add(item.url);
      out.unshift({ ...item, id: randomUUID(), createdAt: Date.now(), read: false, favorite: false });
    }
    return out.slice(0, 500);
  }

  runNow() {
    return this.runPatrol();
  }

  status() {
    return {
      running: this.running,
      lastRun: this.lastRun,
      lastStatus: this.lastStatus,
      lastError: this.lastError,
      paused: this.paused,
      fullscreen: this.fullscreen,
      pendingCount: this.bubblePending.length,
    };
  }
}
