const canvas = document.getElementById("pet");
const ctx = canvas.getContext("2d");
const bubbleEl = document.getElementById("bubble");
const fallbackEl = document.getElementById("fallback");

const GRID = 5;
const FPS = 12;
const FRAME_MS = 1000 / FPS;
const TOTAL = GRID * GRID;
const ACTIONS = ["idle", "sleep", "walk", "discover", "deliver", "pet"];
const SINGLE_SHOT = new Set(["discover", "deliver", "pet"]);

let petDir = "";
let sheets = {};      // action -> Image
let singleFrame = {}; // action -> bool（true 表示用单帧 + 程序动画）
let currentAction = "idle";
let frameIndex = 0;
let lastFrameTime = 0;
let bubbleTimer = null;
let currentBubble = null;
let dragging = false;
let dragOffset = { x: 0, y: 0 };
let winBounds = null;
let hitThrottle = 0;
let blinkUntil = 0;
let nextBlink = 4000;

async function init() {
  try {
    petDir = await window.scoutcat.getPetDir();
  } catch {
    petDir = "";
  }

  const ok = await loadSheet("idle");
  if (!ok) {
    fallbackEl.style.display = "flex";
    canvas.style.display = "none";
  } else {
    fallbackEl.style.display = "none";
  }
  for (const a of ACTIONS) if (a !== "idle") loadSheet(a);
  requestAnimationFrame(loop);
  setupInteraction();
  setupEvents();
}

/** 加载动作图集；失败则回退到角色标准图（单帧） */
async function loadSheet(action) {
  if (action in sheets) return true;
  const tryLoad = async (file) => {
    const img = new Image();
    img.src = `${petDir}${file}`;
    try {
      await img.decode();
      return img;
    } catch {
      return null;
    }
  };
  let img = await tryLoad(`${action}.png`);
  if (img) {
    sheets[action] = img;
    singleFrame[action] = false;
    return true;
  }
  img = await tryLoad("character-base.png");
  if (img) {
    sheets[action] = img;
    singleFrame[action] = true;
    return true;
  }
  return false;
}

function drawSheet(img, W, H, t) {
  const fw = img.naturalWidth / GRID;
  const fh = img.naturalHeight / GRID;
  const frame = Math.min(fw, fh);
  const size = Math.min(256, W * 0.86);
  const x = (W - size) / 2;
  const y = H - size;
  const col = frameIndex % GRID;
  const row = Math.floor(frameIndex / GRID) % GRID;
  ctx.clearRect(0, 0, W, H);
  ctx.drawImage(img, col * fw, row * fh, fw, fh, x, y, size, size);
}

function drawSingle(img, W, H, t) {
  const breath = 1 + 0.018 * Math.sin(t / 900);
  const bob = 3 * Math.sin(t / 1200);
  const blinkState = updateBlink();

  const maxW = W * 0.86;
  const maxH = H * 0.72;
  const base = Math.min(maxW, maxH, 256);
  const size = base * breath;
  const x = (W - size) / 2;
  const y = H - size - H * 0.04 + bob;

  ctx.clearRect(0, 0, W, H);
  ctx.drawImage(img, x, y, size, size);

  if (blinkState) {
    ctx.save();
    ctx.strokeStyle = "#1c1c1c";
    ctx.lineWidth = Math.max(1.5, size * 0.012);
    ctx.lineCap = "round";
    const ey = y + size * 0.3;
    const e1x = x + size * 0.38;
    const e2x = x + size * 0.62;
    ctx.beginPath();
    ctx.moveTo(e1x - size * 0.045, ey);
    ctx.lineTo(e1x + size * 0.045, ey);
    ctx.moveTo(e2x - size * 0.045, ey);
    ctx.lineTo(e2x + size * 0.045, ey);
    ctx.stroke();
    ctx.restore();
  }
}

function updateBlink() {
  const now = performance.now();
  if (now > nextBlink && !blinkUntil) {
    blinkUntil = now + 130;
    nextBlink = now + 2600 + Math.random() * 3200;
  }
  if (blinkUntil && now > blinkUntil) blinkUntil = 0;
  return Boolean(blinkUntil);
}

function drawFrame(t = performance.now()) {
  const img = sheets[currentAction];
  if (!img || !img.naturalWidth) return;
  const W = canvas.clientWidth || 320;
  const H = canvas.clientHeight || 381;
  const dpr = window.devicePixelRatio || 1;
  const pw = Math.round(W * dpr);
  const ph = Math.round(H * dpr);
  if (canvas.width !== pw || canvas.height !== ph) {
    canvas.width = pw;
    canvas.height = ph;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  if (singleFrame[currentAction]) drawSingle(img, W, H, t);
  else drawSheet(img, W, H, t);
}

function loop(t) {
  const isSheet = !singleFrame[currentAction];
  if (!isSheet || t - lastFrameTime >= FRAME_MS) {
    lastFrameTime = t;
    if (isSheet) frameIndex = (frameIndex + 1) % TOTAL;
    drawFrame(t);
  }
  requestAnimationFrame(loop);
}

function play(action) {
  if (!ACTIONS.includes(action)) action = "idle";
  currentAction = action;
  frameIndex = 0;
  lastFrameTime = 0;
  drawFrame();
  if (SINGLE_SHOT.has(action)) {
    setTimeout(() => {
      if (currentAction === action) play("idle");
    }, 2200);
  }
}

function hitTest(x, y) {
  const rect = canvas.getBoundingClientRect();
  const px = x - rect.left;
  const py = y - rect.top;
  if (px < 0 || py < 0 || px >= canvas.width || py >= canvas.height) return false;
  try {
    const d = ctx.getImageData(Math.floor(px), Math.floor(py), 1, 1).data;
    return d[3] > 24;
  } catch {
    return true;
  }
}

async function refreshBounds() {
  try {
    winBounds = await window.scoutcat.getPetBounds();
  } catch {
    winBounds = null;
  }
}

function setupInteraction() {
  document.addEventListener("mousemove", (e) => {
    if (dragging) {
      window.scoutcat.movePet(e.screenX - dragOffset.x, e.screenY - dragOffset.y);
      return;
    }
    const now = performance.now();
    if (now - hitThrottle < 40) return;
    hitThrottle = now;
    window.scoutcat.setClickThrough(!hitTest(e.clientX, e.clientY));
  });

  document.addEventListener("mousedown", async (e) => {
    if (!hitTest(e.clientX, e.clientY)) return;
    if (!winBounds) await refreshBounds();
    dragging = true;
    dragOffset.x = e.screenX - (winBounds?.x ?? 0);
    dragOffset.y = e.screenY - (winBounds?.y ?? 0);
    window.scoutcat.setClickThrough(false);
    play("walk");
  });

  document.addEventListener("mouseup", async () => {
    if (!dragging) return;
    dragging = false;
    await refreshBounds();
    window.scoutcat.setClickThrough(true);
    play("pet");
    // 边缘停靠：靠近屏幕边缘时由主进程自动吸附
    try {
      await window.scoutcat.dockPet();
    } catch { /* 停靠失败忽略 */ }
  });

  document.addEventListener("mouseleave", () => {
    if (!dragging) window.scoutcat.setClickThrough(true);
  });
}

function showBubble(message) {
  if (!message) return hideBubble();
  currentBubble = message;
  bubbleEl.innerHTML = "";
  const div = document.createElement("div");
  div.className = "text";
  div.textContent = message.summary || message.title || "";
  const span = document.createElement("span");
  span.className = "src";
  span.textContent = message.source || "";
  bubbleEl.appendChild(div);
  bubbleEl.appendChild(span);
  bubbleEl.classList.add("show");
  play("deliver");
  clearTimeout(bubbleTimer);
  bubbleTimer = setTimeout(hideBubble, 9000);
}

function hideBubble() {
  bubbleEl.classList.remove("show");
  currentBubble = null;
}

bubbleEl.addEventListener("click", () => {
  if (currentBubble?.url) window.scoutcat.openUrl(currentBubble.url);
  hideBubble();
});

function setupEvents() {
  window.scoutcat.onPetAction((a) => play(a));
  window.scoutcat.onBubble((m) => (m ? showBubble(m) : hideBubble()));
}

init();
