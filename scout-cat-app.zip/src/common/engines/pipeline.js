/**
 * 巡逻管道：编排搜索 → 去重 → 判断 → 校验 → 落库 → 提醒决策
 * 文档第 4、8、9 节
 */

import { randomUUID } from "node:crypto";
import { getEngine as defaultGetEngine } from "./registry.js";
import { titleSignature } from "./dedup.js";
import { contentFingerprint } from "./normalize.js";

let _defaultStore = null;
async function getDefaultStore() {
  if (!_defaultStore) {
    const { getStore } = await import("../../main/store.js");
    _defaultStore = getStore();
  }
  return _defaultStore;
}

/**
 * 执行一次完整巡逻
 * @param {object} cfg 配置（含 engine、interests 等）
 * @param {object|null} storeOverride 可注入内存 store（测试用）
 * @param {object|null} engineOverride 可注入引擎实例（测试用）
 */
export async function runPipeline(cfg = {}, storeOverride = null, engineOverride = null) {
  const store = storeOverride || (await getDefaultStore());
  const engine = engineOverride || defaultGetEngine(cfg.engine || "demo");

  const historyEvents = store.get("events", []);

  const result = await engine.run({
    prompt: "",
    timeoutMs: 300000,
    cfg: { ...cfg, historyEvents },
  });

  if (!result?.ok) {
    return {
      ok: false,
      error: result?.error || "引擎失败",
      items: [],
      queries: result?.queries || [],
    };
  }

  const candidates = result.candidates || [];
  const decisions = result.decisions || [];

  // 落库：文章 upsert + 候选状态
  const articleEventId = upsertArticles(store, candidates);
  const candidateStatus = store.get("candidateStatus", {});

  // 校验 + 处理 decisions
  const validated = validateDecisions(decisions, candidates, historyEvents);

  // 处理分类：创建/更新事件，生成通知
  const notifyItems = [];
  const pendingReview = [];
  const processed = { created: 0, updated: 0, duplicate: 0, uncertain: 0, rejected: 0 };

  for (const d of validated) {
    const validIds = d.candidate_ids.filter((id) => candidates.some((c) => c.candidateId === id));
    if (!validIds.length) { processed.rejected++; continue; }

    if (d.existing_event_id && !historyEvents.some((e) => e.id === d.existing_event_id)) {
      processed.rejected++;
      continue;
    }

    let sourceArticle = null;
    if (d.source_candidate_id) {
      sourceArticle = candidates.find((c) => c.candidateId === d.source_candidate_id) || null;
      if (!sourceArticle) { processed.rejected++; continue; }
    }
    if (!sourceArticle && validIds.length) {
      sourceArticle = candidates.find((c) => c.candidateId === validIds[0]) || null;
    }

    const url = sourceArticle?.url || "";
    if (!/^https?:\/\//.test(url)) { processed.rejected++; continue; }

    // 标记候选已处理
    for (const id of validIds) {
      candidateStatus[id] = { status: d.classification, at: new Date().toISOString(), url };
    }

    if (d.classification === "new_event") {
      const eventId = randomUUID();
      const event = {
        id: eventId,
        topic: sourceArticle?.source || "",
        subject: extractSubject(d.fact || sourceArticle?.title || ""),
        knownFacts: d.fact || sourceArticle?.title || "",
        status: "active",
        firstOccurredAt: d.published_at || sourceArticle?.publishedAt || null,
        relatedArticles: validIds.map((id) => candidates.find((c) => c.candidateId === id)?.url).filter(Boolean),
        lastSubstantiveUpdate: d.fact || null,
        updatedAt: new Date().toISOString(),
        titleSignature: titleSignature(d.fact || sourceArticle?.title || ""),
      };
      store.set("events", [...store.get("events", []), event]);
      // 关联文章 → 事件
      linkArticlesToEvent(store, event.relatedArticles, eventId);
      processed.created++;
      notifyItems.push(buildNotifyItem(event, d, sourceArticle));
    } else if (d.classification === "substantive_update") {
      const evId = d.existing_event_id;
      const events = store.get("events", []);
      const ev = events.find((e) => e.id === evId);
      if (!ev) { processed.uncertain++; continue; }
      const existingNotifs = store.get("notifications", []);
      const already = existingNotifs.some((n) => n.eventId === evId && n.version === (d.change || d.fact));
      if (already) { processed.duplicate++; continue; }

      ev.lastSubstantiveUpdate = d.fact || d.change || ev.lastSubstantiveUpdate;
      ev.updatedAt = new Date().toISOString();
      ev.status = "active";
      const urls = validIds.map((id) => candidates.find((c) => c.candidateId === id)?.url).filter(Boolean);
      ev.relatedArticles = [...new Set([...(ev.relatedArticles || []), ...urls])];
      store.set("events", events);
      linkArticlesToEvent(store, urls, evId);
      processed.updated++;
      notifyItems.push(buildNotifyItem(ev, d, sourceArticle));
    } else if (d.classification === "duplicate") {
      const evId = d.existing_event_id;
      if (evId) {
        const events = store.get("events", []);
        const ev = events.find((e) => e.id === evId);
        if (ev) {
          const urls = validIds.map((id) => candidates.find((c) => c.candidateId === id)?.url).filter(Boolean);
          ev.relatedArticles = [...new Set([...(ev.relatedArticles || []), ...urls])];
          ev.updatedAt = new Date().toISOString();
          store.set("events", events);
          linkArticlesToEvent(store, urls, evId);
        }
      }
      processed.duplicate++;
    } else {
      // uncertain：持久化到待核实列表
      processed.uncertain++;
      pendingReview.push({
        id: randomUUID(),
        fact: d.fact || sourceArticle?.title || "",
        url,
        source: sourceArticle?.source || "",
        publishedAt: sourceArticle?.publishedAt || d.published_at || null,
        reason: "证据不足，待核实",
        createdAt: new Date().toISOString(),
        candidateIds: validIds,
      });
    }
  }

  // 候选状态落盘
  store.set("candidateStatus", candidateStatus);

  // 待核实列表（去重 + 限量）
  if (pendingReview.length) {
    const existing = store.get("pendingReview", []);
    const seen = new Set(existing.map((p) => p.url));
    const merged = [...existing];
    for (const p of pendingReview) {
      if (p.url && !seen.has(p.url)) { merged.unshift(p); seen.add(p.url); }
    }
    store.set("pendingReview", merged.slice(0, 200));
  }

  // 事件保存期限清理（文档第 6 节）
  pruneEvents(store, cfg.eventRetentionDays);

  // 落库通知（幂等）
  const notifs = store.get("notifications", []);
  for (const item of notifyItems) {
    const exists = notifs.some((n) => n.id === item.id);
    if (!exists) notifs.push(item);
  }
  store.set("notifications", notifs.slice(0, 500));

  // 更新关注任务状态
  updateWatchTasks(store, candidates, notifyItems);

  // 转换为背包 items
  const items = notifyItems.map((n) => ({
    title: n.bubble || n.fact || "新发现",
    summary: n.bubble || n.fact || "",
    url: n.url || "",
    source: n.source || "",
    publishedAt: n.publishedAt || null,
    firstSeenAt: n.firstSeenAt || null,
    reason: n.relevanceReason || "",
    watchTaskId: n.watchTaskId || "",
    eventId: n.eventId,
    shouldNotify: n.shouldNotify ?? true,
  }));

  return {
    ok: true,
    items,
    queries: result.queries || [],
    processed,
    error: "",
  };
}

/** 校验 decisions 结构（文档第 8 节） */
export function validateDecisions(decisions, candidates, historyEvents) {
  const out = [];
  const seen = new Set();
  for (const d of decisions) {
    if (!d || typeof d !== "object") continue;
    const classification = d.classification;
    if (!["new_event", "substantive_update", "duplicate", "uncertain"].includes(classification)) continue;
    if (!Array.isArray(d.candidate_ids)) continue;
    const key = [...d.candidate_ids].sort().join(",");
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      candidate_ids: d.candidate_ids.filter((id) => candidates.some((c) => c.candidateId === id)),
      classification,
      existing_event_id: d.existing_event_id || null,
      fact: d.fact || "",
      change: d.change || null,
      bubble: d.bubble || null,
      source_candidate_id: d.source_candidate_id || null,
      published_at: d.published_at || null,
      relevance_reason: d.relevance_reason || null,
    });
  }
  return out;
}

/** 文章 upsert 到 store，返回 candidateId → eventId 映射 */
function upsertArticles(store, candidates) {
  const articles = store.get("articles", []);
  const byUrl = new Map(articles.map((a) => [a.url, a]));
  for (const c of candidates) {
    if (!c.url) continue;
    const existing = byUrl.get(c.url);
    if (existing) {
      existing.lastCheckedAt = new Date().toISOString();
      if (c.summary && c.summary.length > (existing.summary || "").length) existing.summary = c.summary;
      if (c.publishedAt && !existing.publishedAt) existing.publishedAt = c.publishedAt;
      if (c.contentSnippet && c.contentSnippet.length > (existing.contentSnippet || "").length) {
        existing.contentSnippet = c.contentSnippet;
        existing.contentFingerprint = contentFingerprint(c.title, c.contentSnippet);
      } else {
        const fp = contentFingerprint(c.title, c.summary || c.contentSnippet || "");
        if (fp && fp !== existing.contentFingerprint) existing.contentFingerprint = fp;
      }
    } else {
      const article = {
        id: randomUUID(),
        url: c.url,
        title: c.title || "",
        summary: c.summary || "",
        source: c.source || "",
        publishedAt: c.publishedAt || null,
        firstSeenAt: new Date().toISOString(),
        lastCheckedAt: new Date().toISOString(),
        contentFingerprint: contentFingerprint(c.title, c.summary || c.contentSnippet || ""),
        contentSnippet: c.contentSnippet || "",
        eventId: null,
        candidateId: c.candidateId,
      };
      articles.unshift(article);
      byUrl.set(c.url, article);
    }
  }
  store.set("articles", articles.slice(0, 2000));
  const map = {};
  for (const a of articles) map[a.candidateId] = a.eventId;
  return map;
}

/** 将文章关联到事件 */
function linkArticlesToEvent(store, urls, eventId) {
  if (!urls?.length || !eventId) return;
  const articles = store.get("articles", []);
  let changed = false;
  for (const a of articles) {
    if (urls.includes(a.url) && a.eventId !== eventId) {
      a.eventId = eventId;
      changed = true;
    }
  }
  if (changed) store.set("articles", articles);
}

/** 事件保存期限清理 */
function pruneEvents(store, retentionDays = 30) {
  if (!retentionDays || retentionDays <= 0) return;
  const cutoff = Date.now() - retentionDays * 86400e3;
  const events = store.get("events", []);
  const kept = events.filter((e) => {
    const t = e.updatedAt ? new Date(e.updatedAt).getTime() : 0;
    return t >= cutoff;
  });
  if (kept.length !== events.length) store.set("events", kept);
}

/** 构建通知项（状态细分） */
function buildNotifyItem(event, d, sourceArticle) {
  const url = sourceArticle?.url || (event.relatedArticles || [])[0] || "";
  return {
    id: randomUUID(),
    eventId: event.id,
    version: d.change || d.fact || "",
    bubble: d.bubble || null,
    fact: d.fact || "",
    url,
    source: sourceArticle?.source || event.topic || "",
    publishedAt: d.published_at || sourceArticle?.publishedAt || null,
    firstSeenAt: sourceArticle?.firstSeenAt || new Date().toISOString(),
    relevanceReason: d.relevance_reason || "",
    watchTaskId: sourceArticle?.taskId || "",
    status: "pending",        // pending → shown → read/favorite/ignored
    createdAt: new Date().toISOString(),
    notifiedAt: null,
    shouldNotify: Boolean(d.bubble),
  };
}

/** 更新关注任务状态 */
function updateWatchTasks(store, candidates, notifyItems) {
  const tasks = store.get("watchTasks", []);
  if (!tasks.length) return;
  let changed = false;
  const updated = tasks.map((t) => {
    const hit = notifyItems.find((n) => n.watchTaskId === t.target || n.watchTaskId === t.id);
    const patch = { lastCheck: Date.now() };
    if (hit && t.status === "active") {
      patch.status = "done";
      patch.doneAt = Date.now();
    }
    if (patch.status || patch.lastCheck !== t.lastCheck) changed = true;
    return { ...t, ...patch };
  });
  if (changed) store.set("watchTasks", updated);
}

/** 从文本提取事件主体 */
function extractSubject(text) {
  if (!text) return "";
  return String(text).trim().slice(0, 20);
}
