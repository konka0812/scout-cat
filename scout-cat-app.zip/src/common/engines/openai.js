/**
 * OpenAI 兼容引擎：多主题搜索 + 事件判断
 *
 * 流程（文档第 4 节）：
 *   1. 生成 1～3 条主题查询（轮换）
 *   2. 逐条搜索 + 标准化 + URL 去重
 *   3. 批内标题相似去重
 *   4. 关联历史事件
 *   5. 按需 Fetch 高价值候选正文
 *   6. 调模型判断（decisions 格式）
 *   7. 返回候选 + 模型决策（落库由 pipeline 负责）
 */

import { search, fetchPage } from "./search.js";
import { buildSearchQueries, buildJudgeSystemPrompt, buildJudgeUserPrompt } from "./prompt.js";
import { normalizeArticle, normalizeUrl, extractSource } from "./normalize.js";
import { dedupByUrl, dedupByTitleSimilarity, relateToHistory } from "./dedup.js";

export const openaiAdapter = {
  name: "openai",
  label: "OpenAI 兼容 + 搜索",
  docs: "https://api-docs.deepseek.com/zh-cn/api/search.md",

  async check(cfg = {}) {
    const baseUrl = cfg.baseURL || "";
    const apiKey = cfg.apiKey || "";
    const model = cfg.model || "";
    const searchKey = cfg.searchKey || apiKey;
    const searchBase = cfg.searchBase || "https://api.deepseek.com";
    const result = { ok: true, version: model, message: "", model: false, search: false };

    if (!baseUrl || !apiKey || !model) {
      return { ok: false, version: "", message: "请在设置中填写 Base URL、API Key 和 Model" };
    }
    // 测试模型
    try {
      const res = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model, messages: [{ role: "user", content: "ping" }], max_tokens: 5 }),
      });
      if (res.ok) result.model = true;
      else {
        const err = await res.json().catch(() => ({}));
        result.message = `模型 HTTP ${res.status}: ${err?.error?.message || res.statusText}`;
      }
    } catch (e) {
      result.message = `模型: ${e.message}`;
    }
    // 测试搜索
    try {
      const sres = await fetch(`${searchBase}/v1/tools/search`, {
        method: "POST",
        headers: { Authorization: `Bearer ${searchKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ query: "AI", count: 1 }),
      });
      if (sres.ok) result.search = true;
      else {
        const err = await sres.json().catch(() => ({}));
        result.message += `${result.message ? "；" : ""}搜索 HTTP ${sres.status}: ${err?.error?.message || sres.statusText}`;
      }
    } catch (e) {
      result.message += `${result.message ? "；" : ""}搜索: ${e.message}`;
    }
    result.ok = result.model || result.search;
    return result;
  },

  async run({ prompt, timeoutMs = 300000, cfg = {} }) {
    const baseUrl = cfg.baseURL || "";
    const apiKey = cfg.apiKey || "";
    const model = cfg.model || "";
    const searchKey = cfg.searchKey || apiKey;
    const searchBase = cfg.searchBase || "https://api.deepseek.com";
    const rotation = cfg.rotation || 0;
    const feedback = cfg.feedback || {};
    const maxTokens = cfg.modelMaxTokens || 3000;
    const fetchLimit = cfg.fetchLimit || 6;
    const queryCount = cfg.queryCount || 3;
    const useJsonMode = cfg.useJsonMode !== false;

    const now = new Date().toISOString();

    // 1. 生成主题查询（含偏好反馈）
    const queries = buildSearchQueries({
      interests: cfg.interests || [],
      watchTasks: cfg.watchTasks || [],
      blockedTopics: cfg.blockedTopics || [],
      feedback,
      rotation,
      maxQueries: queryCount,
    });

    // 2. 逐条搜索 + 标准化 + URL 去重
    let allArticles = [];
    const queryResults = [];
    for (const q of queries) {
      try {
        const raw = await search(q.query, { apiKey: searchKey, count: 10, needContent: false, base: searchBase });
        const articles = (raw || []).map((r, i) => normalizeArticle(r, {
          candidateId: `q${queryResults.length}-c${i}`,
          taskId: q.topic,
        }));
        const { kept } = dedupByUrl(articles);
        allArticles.push(...kept);
        queryResults.push({ topic: q.topic, ok: true, count: kept.length });
      } catch (e) {
        queryResults.push({ topic: q.topic, ok: false, error: e.message });
      }
    }

    if (!allArticles.length) {
      return { ok: true, candidates: [], decisions: [], queries: queryResults, error: "", raw: "" };
    }

    // 3. 批内标题相似去重
    const { kept: deduped } = dedupByTitleSimilarity(allArticles);

    // 4. 关联历史事件
    const historyEvents = cfg.historyEvents || [];
    const matchedEventIds = relateToHistory(deduped, historyEvents);
    const candidates = deduped.map((a, i) => ({
      ...a,
      matchedEventId: matchedEventIds[i] || null,
    }));

    // 5. 按需 Fetch：对高价值候选读取正文（受 fetchLimit 限制）
    let fetchCount = 0;
    for (const c of candidates) {
      if (fetchCount >= fetchLimit) break;
      const isOfficial = /github\.com|gitlab|ietf|w3|python|nodejs|mozilla|apple|microsoft|google|openai|anthropic|deepseek/.test(c.source || "");
      const hasWatchMatch = Boolean(c.matchedEventId);
      if ((isOfficial || hasWatchMatch) && c.url && !c.contentSnippet) {
        try {
          const page = await fetchPage(c.url, { apiKey: searchKey, base: searchBase });
          c.contentSnippet = (page.content || "").slice(0, 1500);
          fetchCount++;
        } catch {
          // 抓取失败不阻塞
        }
      }
    }

    // 6. 调模型判断
    const systemPrompt = buildJudgeSystemPrompt();
    const userPrompt = buildJudgeUserPrompt({
      interests: cfg.interests,
      blockedTopics: cfg.blockedTopics,
      watchTasks: cfg.watchTasks,
      feedback,
      now,
      candidates: candidates.slice(0, 12),
      events: historyEvents,
    });

    let decisions = [];
    let modelError = "";
    try {
      const body = {
        model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.2,
        max_tokens: maxTokens,
      };
      if (useJsonMode) body.response_format = { type: "json_object" };
      const res = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        modelError = `模型 HTTP ${res.status}: ${err?.error?.message || res.statusText}`;
      } else {
        const data = await res.json();
        const text = data.choices?.[0]?.message?.content || "";
        const parsed = parseDecisions(text);
        decisions = parsed.decisions || [];
        if (parsed.error) modelError = parsed.error;
      }
    } catch (e) {
      modelError = e.message;
    }

    return {
      ok: !modelError,
      candidates: candidates.map((c) => ({
        candidateId: c.candidateId,
        url: c.url,
        title: c.title,
        summary: c.summary,
        source: c.source,
        publishedAt: c.publishedAt,
        contentSnippet: c.contentSnippet || "",
        matchedEventId: c.matchedEventId,
        taskId: c.taskId,
      })),
      decisions,
      queries: queryResults,
      error: modelError,
      raw: "",
    };
  },
};

/** 解析模型输出的 decisions JSON */
export function parseDecisions(text) {
  if (!text) return { decisions: [], error: "empty response" };
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    let depth = 0, inStr = false, esc = false, start = -1;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (esc) { esc = false; continue; }
      if (ch === "\\") { esc = true; continue; }
      if (ch === '"') { inStr = !inStr; continue; }
      if (inStr) continue;
      if (ch === "{") { if (depth === 0) start = i; depth++; }
      else if (ch === "}") {
        depth--;
        if (depth === 0 && start >= 0) {
          try { json = JSON.parse(text.slice(start, i + 1)); } catch {}
          break;
        }
      }
    }
  }
  if (!json || !Array.isArray(json.decisions)) {
    return { decisions: [], error: "invalid decisions JSON" };
  }
  const valid = new Set(["new_event", "substantive_update", "duplicate", "uncertain"]);
  const decisions = json.decisions.filter((d) => valid.has(d.classification));
  return { decisions, error: "" };
}
